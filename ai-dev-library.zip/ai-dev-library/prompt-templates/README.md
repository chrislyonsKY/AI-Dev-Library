# Prompt Templates — Reusable AI Prompts

> Copy-paste prompts for common development tasks.
> Use with Claude Code, Claude Chat, or any AI coding assistant.

## Inventory

| Template | File | Use When |
|---|---|---|
| Implementation | `implement.md` | Starting a coding task |
| Code Review | `review.md` | Reviewing existing code |
| Refactor | `refactor.md` | Modernizing or restructuring code |
| Debug | `debug.md` | Investigating and fixing bugs |
| End of Session | `end-session.md` | Wrapping up and committing work |
| Onboard to Codebase | `onboard.md` | Getting AI up to speed on existing code |
