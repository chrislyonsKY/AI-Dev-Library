# Prompt: Implementation Task

```
Read CLAUDE.md, ai-dev/architecture.md, ai-dev/patterns.md, ai-dev/guardrails/.

Implement [specific feature/module].

Before writing code:
1. Confirm you understand the module's responsibility
2. List the files you will create or modify
3. Check ai-dev/decisions/ for any prior decisions affecting this module
4. Show me the plan

Do not proceed until I type Engage.
```

## Variant: Implementation with Spec

```
Read CLAUDE.md, ai-dev/spec.md, ai-dev/guardrails/.

Implement the feature described in ai-dev/spec.md.

Before writing code:
1. Summarize the requirements you'll implement (FR-01, FR-02, etc.)
2. List the files you will create or modify
3. Identify any requirements that are ambiguous or have open questions
4. Propose your implementation order (which requirement first?)
5. Show me the plan

Do not proceed until I type Engage.
```

## Variant: Targeted Implementation

```
Read CLAUDE.md, ai-dev/guardrails/.

In [file_path], implement [specific function/method].

Requirements:
- [Requirement 1]
- [Requirement 2]
- Error handling for: [specific failure modes]
- Must follow patterns in ai-dev/patterns.md

Show me the function signature and approach before writing the full implementation.
```
