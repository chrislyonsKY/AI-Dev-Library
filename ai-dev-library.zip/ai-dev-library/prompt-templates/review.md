# Prompt: Code Review

```
Read CLAUDE.md, ai-dev/patterns.md, ai-dev/guardrails/.

Review [file or module path] for:
- Adherence to project conventions in CLAUDE.md
- Compliance with ai-dev/guardrails/ constraints
- Error handling completeness
- Edge cases
- Anti-patterns listed in patterns.md

Produce a numbered list of findings with severity:
- 🔴 Critical: Must fix (data loss, security, crash, guardrail violation)
- 🟡 Warning: Should fix (missing error handling, edge case, performance)
- 🔵 Info: Optional improvement (readability, style)

For each finding, include:
1. Location (file:line or function name)
2. What the issue is
3. Suggested fix (with code if applicable)
```

## Variant: Security-Focused Review

```
Read CLAUDE.md, ai-dev/guardrails/data-handling.md, ai-dev/guardrails/coding-standards.md.

Security review [file or module path] for:
- SQL injection vulnerabilities
- Hardcoded credentials or secrets
- PII in logs or error messages
- Input validation gaps
- Path traversal risks
- Insecure deserialization

Rate each finding as 🔴 Critical or 🟡 Warning.
Include the exact code location and a concrete fix.
```

## Variant: Pre-Merge Review

```
Read CLAUDE.md, ai-dev/guardrails/.

Review the following changes for merge readiness:
[paste diff or list changed files]

Check:
- [ ] No guardrail violations
- [ ] Error handling on all new code paths
- [ ] No hardcoded values that should be config
- [ ] No credentials or PII in the diff
- [ ] Naming follows project conventions
- [ ] New functions have docstrings/XML docs
- [ ] No dead code or TODOs without context

Summarize: Ready to merge? Or list blocking issues.
```
