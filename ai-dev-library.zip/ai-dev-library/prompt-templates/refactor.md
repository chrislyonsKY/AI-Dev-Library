# Prompt: Refactor

```
Read CLAUDE.md, ai-dev/patterns.md, ai-dev/guardrails/.

Analyze [file or module path] for refactoring opportunities.

For each opportunity:
1. Identify the code smell (God Function, Duplication, Nested Conditionals, etc.)
2. Explain why it matters (maintenance cost, bug risk, readability)
3. Propose a specific refactoring with before/after code
4. Estimate risk level (Low/Medium/High)

Prioritize findings by impact. Do NOT make any changes — show me the plan first.
```

## Variant: Legacy Migration

```
Read CLAUDE.md, ai-dev/guardrails/.

Analyze [file path] for modernization from [old pattern] to [new pattern].
Example: ArcMap Python 2.7 → ArcGIS Pro Python 3.9+

For each change needed:
1. Old pattern (with line reference)
2. New pattern (with code)
3. Breaking change risk (will behavior change?)
4. Dependencies affected

Produce a phased migration plan where each phase is independently deployable.
Do NOT make changes until I approve the plan.
```

## Variant: Extract Module

```
Read CLAUDE.md, ai-dev/architecture.md.

[file path] has grown too large. Analyze it and propose how to decompose it into
smaller, focused modules.

For each proposed module:
1. Name and single responsibility
2. Which functions/classes move there
3. Interface (what it exports)
4. Dependencies (what it imports)

Show the proposed directory structure and module interfaces.
Do NOT move code until I approve.
```
