# Prompt: End of Session

```
Read CLAUDE.md.

Summarize all changes made this session.

Group changes into logical git commits using conventional commit format:
  feat(scope): description
  fix(scope): description
  refactor(scope): description
  docs(scope): description
  chore(scope): description

For each proposed commit:
1. Commit message (subject + optional body)
2. Files included
3. Brief description of what changed and why

Show proposed commits. Do not run git until I type Engage.
```

## Variant: Session Notes for CLAUDE.md

```
Read CLAUDE.md.

Before we wrap up, update the project context:

1. What decisions were made this session that should be recorded in ai-dev/decisions/?
2. What patterns were established that should be added to ai-dev/patterns.md?
3. What open questions or TODOs remain?
4. Should any ai-dev/guardrails/ be updated based on what we learned?
5. Does CLAUDE.md need any updates (new modules, changed conventions)?

Show me the proposed updates. Do not modify files until I approve.
```

## Variant: Handoff Summary

```
Read CLAUDE.md.

I'm pausing work on this project. Create a handoff summary that another developer
(or a future AI session) can use to pick up where I left off.

Include:
1. What was accomplished this session
2. What is in progress but incomplete
3. Known issues or bugs introduced
4. Next steps (prioritized)
5. Files that were modified (with brief description of changes)
6. Any gotchas or context that isn't captured in the code comments
```
