# Prompt: Onboard to Codebase

```
Read CLAUDE.md completely.
Then read ai-dev/architecture.md.
Then read ai-dev/guardrails/ (all files).
Then read ai-dev/patterns.md.

Now summarize your understanding:
1. What does this project do? (one paragraph)
2. What is the tech stack?
3. What are the key modules and their responsibilities?
4. What are the critical guardrails I must follow?
5. What patterns are established?
6. What should I NOT do?

After your summary, I'll confirm or correct your understanding.
```

## Variant: Onboard to Specific Module

```
Read CLAUDE.md, ai-dev/architecture.md.

I need you to work on the [module name] module.

Before doing anything:
1. Read all files in [module path]
2. Summarize what this module does
3. List its dependencies (what it imports)
4. List its dependents (what imports it)
5. Identify any patterns specific to this module
6. Note any TODOs, known issues, or technical debt

Show me your understanding before I give you a task.
```

## Variant: Onboard from Zero (No ai-dev/)

```
I'm giving you a codebase without AI development docs. Before we start working:

1. Read the directory structure
2. Read README.md (if it exists)
3. Read the main entry point(s)
4. Read config/setup files (package.json, requirements.txt, .csproj, etc.)
5. Scan for key patterns in the code

Then tell me:
- What this project does
- What tech stack it uses
- How it's organized
- What conventions you observe
- What's missing (tests, docs, error handling)
- What you'd want to know before making changes

After this, I'll provide additional context and we can create a CLAUDE.md together.
```
