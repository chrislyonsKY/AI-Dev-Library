# Prompt: Debug

```
Read CLAUDE.md, ai-dev/guardrails/.

I'm seeing this error:
[paste error message / traceback / unexpected behavior]

Context:
- File: [file path]
- Function: [function name]
- Input that triggers it: [what data/action causes the bug]
- Frequency: [always / intermittent / only with specific data]

Investigate:
1. What is the most likely root cause?
2. What other causes should be ruled out?
3. What's the minimal fix?
4. What edge cases does the fix need to handle?
5. What test would prevent this from recurring?

Show me the analysis before proposing a fix.
```

## Variant: Intermittent Bug

```
Read CLAUDE.md.

I have an intermittent bug:
- Symptom: [what happens]
- Frequency: [how often, any pattern?]
- Environment: [where it happens]
- Recent changes: [what changed before this started]

This is likely a:
- [ ] Race condition / timing issue
- [ ] Data-dependent edge case
- [ ] Environment/configuration difference
- [ ] Resource exhaustion (memory, connections, handles)

Propose a diagnostic strategy:
1. What logging should I add to narrow it down?
2. What conditions should I monitor?
3. What data patterns should I look for?
```

## Variant: Performance Issue

```
Read CLAUDE.md, ai-dev/guardrails/performance.md.

[file/function/query] is too slow:
- Current performance: [measured time]
- Target performance: [expected time]
- Data volume: [how much data is involved]

Analyze:
1. Where is the bottleneck? (CPU, I/O, memory, network, query plan)
2. What's the algorithmic complexity?
3. Propose optimizations ranked by impact vs. effort
4. What's the expected improvement for each?

Do NOT refactor for performance without measuring first.
```
