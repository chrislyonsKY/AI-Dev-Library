# DL-[NNN]: Technology Choice — [Category]

**Date:** YYYY-MM-DD
**Status:** Proposed | Accepted | Superseded by DL-XXX
**Author:** [Name]
**Category:** [Framework | Library | Database | Language | Service | Tool]

## Context

[What capability do we need? What are the constraints (budget, team skills, timeline, compliance)?]

## Evaluation Criteria

| Criterion | Weight | Description |
|---|---|---|
| [Criterion 1] | [H/M/L] | [What we're evaluating] |
| [Criterion 2] | [H/M/L] | [What we're evaluating] |
| [Criterion 3] | [H/M/L] | [What we're evaluating] |

## Candidates

### [Option A]
| Criterion | Score (1-5) | Notes |
|---|---|---|
| [Criterion 1] | [score] | [evidence] |
| [Criterion 2] | [score] | [evidence] |

**Strengths:** [Key advantages]
**Weaknesses:** [Key disadvantages]

### [Option B]
| Criterion | Score (1-5) | Notes |
|---|---|---|
| [Criterion 1] | [score] | [evidence] |
| [Criterion 2] | [score] | [evidence] |

**Strengths:** [Key advantages]
**Weaknesses:** [Key disadvantages]

## Decision

**Selected:** [Option]
**Rationale:** [Why this option best satisfies the weighted criteria]

## Migration Path

[If replacing an existing technology: how will we transition?]

## Revisit Triggers

- [Condition that would warrant re-evaluation]
