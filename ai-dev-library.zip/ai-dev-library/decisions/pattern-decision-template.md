# DL-[NNN]: Pattern Decision — [Pattern Name]

**Date:** YYYY-MM-DD
**Status:** Proposed | Accepted | Superseded by DL-XXX
**Author:** [Name]
**Scope:** [Project-wide | Module-specific | Language-specific]

## Context

[What recurring problem does this pattern address? Why do we need consistency here?]

## The Pattern

### When to Apply

[Specific conditions under which this pattern must be used]

### Implementation

```[language]
// ✅ CORRECT — The approved pattern
[Code example showing the pattern]
```

### Anti-Pattern

```[language]
// ❌ WRONG — What NOT to do
[Code example showing the wrong approach]

// Why it's wrong:
// [Explanation of the consequences]
```

## Decision

[We will use [pattern] for all [context]. This applies to [scope].]

## Exceptions

[Are there cases where this pattern doesn't apply? Under what conditions can it be waived?]

## Enforcement

- [ ] Added to `ai-dev/guardrails/coding-standards.md`
- [ ] Added to `ai-dev/patterns.md`
- [ ] Added to relevant agent review checklists
- [ ] Existing code updated to match (or migration plan created)

## References

- [Link to pattern documentation, blog post, or reference implementation]
