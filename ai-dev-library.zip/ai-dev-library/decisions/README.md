# Decision Record Templates

> Architectural Decision Records (ADRs) for documenting key technical choices.
> Each decision gets its own file, numbered sequentially.

## Inventory

| Template | File | Use When |
|---|---|---|
| Standard ADR | `adr-template.md` | Any architectural or technical decision |
| Technology Choice | `tech-choice-template.md` | Choosing between frameworks, libraries, services |
| Pattern Decision | `pattern-decision-template.md` | Establishing a project-wide code pattern |

## File Naming Convention

`DL-[NNN]-[short-topic-slug].md`

Examples:
- `DL-001-full-refresh-over-upsert.md`
- `DL-002-react-over-angular.md`
- `DL-003-wkid-3089-stateplane.md`
