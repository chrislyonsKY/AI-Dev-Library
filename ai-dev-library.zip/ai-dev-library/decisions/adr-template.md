# DL-[NNN]: [Decision Title]

**Date:** YYYY-MM-DD
**Status:** Proposed | Accepted | Superseded by DL-XXX | Deprecated
**Author:** [Who made this call]
**Deciders:** [Who was involved in the decision]

## Context

[Why this decision was needed. What problem, ambiguity, or tradeoff triggered it. Include enough background that someone reading this in 6 months understands the situation.]

## Decision

[What was decided. Be specific and unambiguous — "We will use X" not "We might consider X."]

## Alternatives Considered

### [Alternative 1]
- **Pros:** [Advantages]
- **Cons:** [Disadvantages]
- **Rejected because:** [Specific reason]

### [Alternative 2]
- **Pros:** [Advantages]
- **Cons:** [Disadvantages]
- **Rejected because:** [Specific reason]

## Consequences

### Positive
- [What this decision enables]

### Negative
- [What this decision constrains or complicates]

### Neutral
- [Side effects that are neither good nor bad]

## Revisit Triggers

[Under what conditions should this decision be reconsidered?]
- [e.g., If data volume exceeds 1M records]
- [e.g., If the library loses active maintenance]

## References

- [Link to relevant docs, PRs, conversations, or research]
