# Specification Templates

> Structured templates for defining work before coding begins.
> Copy the relevant template into your project's `ai-dev/` directory and fill it out.

## Inventory

| Template | File | Use When |
|---|---|---|
| Feature Spec | `feature-spec-template.md` | New feature or module development |
| API Spec | `api-spec-template.md` | REST/service endpoint design |
| Migration Spec | `migration-spec-template.md` | Data migration or system modernization |
| Bug Fix Spec | `bugfix-spec-template.md` | Structured bug investigation and fix |
| Integration Spec | `integration-spec-template.md` | System-to-system integration work |

## Usage

1. Copy the template to `ai-dev/spec.md` (or `ai-dev/specs/[name]-spec.md` for multiple)
2. Fill in all sections — incomplete specs lead to incomplete implementations
3. Reference from CLAUDE.md so AI agents read it before coding
