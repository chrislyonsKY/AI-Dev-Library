# Migration Spec: [Migration Name]

**Status:** Draft | In Review | Approved | In Progress | Complete
**Author:** [Name]
**Date:** [YYYY-MM-DD]
**Target Completion:** [Date]

---

## Overview

[What is being migrated? From where to where? Why now?]

## Current State

### Source System
- **System:** [Name, version]
- **Data Volume:** [Record counts, size]
- **Schema:** [Key tables/feature classes]
- **Issues:** [Why the current state is insufficient]

### Dependencies on Current System
- [System/process that reads from current system]
- [System/process that writes to current system]

## Target State

### Destination System
- **System:** [Name, version]
- **Schema Changes:** [What's different in the target]
- **Improvements:** [What the migration enables]

## Data Mapping

| Source Field | Source Type | Target Field | Target Type | Transform | Notes |
|---|---|---|---|---|---|
| [field] | [type] | [field] | [type] | [rule] | [notes] |

## Migration Strategy

### Approach: [Big Bang / Phased / Parallel Run / Trickle]

[Justify the chosen approach. What are the tradeoffs?]

### Phase 1: [Name] — [Date Range]
- [ ] [Task: e.g., Create target schema]
- [ ] [Task: e.g., Build ETL pipeline]
- [ ] [Task: e.g., Migrate subset of data]
- Verification: [How to confirm this phase succeeded]

### Phase 2: [Name] — [Date Range]
- [ ] [Task]
- Verification: [...]

### Cutover Plan
1. [Step: e.g., Freeze writes to source system]
2. [Step: e.g., Run final migration batch]
3. [Step: e.g., Verify record counts and data integrity]
4. [Step: e.g., Switch consumers to target system]
5. [Step: e.g., Monitor for 48 hours]

## Validation & Verification

| Check | Method | Threshold |
|---|---|---|
| Record count match | Source count vs. target count | 100% match |
| Data integrity | Spot-check [N] random records | 100% field match |
| Spatial integrity | Compare geometries for [N] features | Within [tolerance] |
| Referential integrity | Verify all foreign keys resolve | 0 orphans |
| Performance | Run standard queries on target | Within [X]% of source |

## Rollback Plan

| Trigger | Action | Recovery Time |
|---|---|---|
| Data corruption detected | [Restore from backup / revert to source] | [Time estimate] |
| Performance degradation | [Switch back to source system] | [Time estimate] |
| Integration failures | [Reconnect consumers to source] | [Time estimate] |

## Risks

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Data loss during migration | L | H | Full backup before migration, verification checks |
| Extended downtime | M | H | Run migration during maintenance window |
| Missed field mappings | M | M | Comprehensive data mapping review, test migration |

## Communication Plan

| Audience | Message | When |
|---|---|---|
| [Stakeholders] | Migration scheduled | [Date] |
| [Users] | System downtime window | [Date] |
| [IT team] | Cutover starting | Day-of |
| [All] | Migration complete / rollback | Post-migration |
