# Bug Fix Spec: [Bug Title]

**Status:** Investigating | Root Cause Found | Fix In Progress | Verified | Closed
**Severity:** Critical | High | Medium | Low
**Author:** [Name]
**Date:** [YYYY-MM-DD]
**Reported By:** [Source: user report, monitoring, testing]

---

## Symptoms

[What is the observable behavior? Be specific — include error messages, screenshots, log entries.]

## Expected Behavior

[What should happen instead?]

## Reproduction Steps

1. [Exact step to reproduce]
2. [Exact step to reproduce]
3. [Exact step to reproduce]

**Environment:** [OS, software versions, dataset, user role]
**Frequency:** [Always / Intermittent / Once]

## Root Cause Analysis

### Investigation Log

| Timestamp | Action | Finding |
|---|---|---|
| [time] | [What I checked] | [What I found] |

### Root Cause

[What is actually causing the bug? Be specific about the code path, data condition, or environment issue.]

### Contributing Factors

- [Factor 1: e.g., Missing null check on optional field]
- [Factor 2: e.g., Assumes data is always sorted]

## Fix

### Approach

[What will be changed and why. Include the file(s) and general strategy.]

### Files Modified

| File | Change Description |
|---|---|
| [path/to/file] | [What changed] |

### Testing

| Test | Input | Expected Result | Status |
|---|---|---|---|
| Reproduce original bug | [steps] | [fixed behavior] | ☐ |
| Regression: [related feature] | [steps] | [still works] | ☐ |
| Edge case: [description] | [input] | [expected] | ☐ |

## Prevention

[What should change to prevent this class of bug in the future?]

- [ ] [e.g., Add null check pattern to coding standards]
- [ ] [e.g., Add test case to regression suite]
- [ ] [e.g., Add validation at data entry boundary]
