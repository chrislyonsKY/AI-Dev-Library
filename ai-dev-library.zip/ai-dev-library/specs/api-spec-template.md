# API Spec: [Service/Endpoint Name]

**Status:** Draft | In Review | Approved | In Progress | Complete
**Author:** [Name]
**Date:** [YYYY-MM-DD]
**Base URL:** `[BASE_URL]/api/v[VERSION]`

---

## Overview

[What does this API do? Who are the consumers? What problem does it solve?]

## Authentication

[Auth method: API key, OAuth 2.0, JWT, session cookie, etc.]

## Endpoints

### `[METHOD] /[path]`

**Purpose:** [What this endpoint does]

**Request:**
```
[METHOD] /api/v1/[path]
Content-Type: application/json
Authorization: Bearer [token]
```

**Path Parameters:**

| Parameter | Type | Required | Description |
|---|---|---|---|
| `id` | string | Yes | [Description] |

**Query Parameters:**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `page` | integer | 1 | Page number for pagination |
| `limit` | integer | 25 | Results per page (max: 100) |
| `sort` | string | `-created_date` | Sort field (prefix `-` for descending) |
| `status` | string | — | Filter by status |

**Request Body:**
```json
{
  "field_name": "string (required, max 200 chars)",
  "numeric_field": "number (required, positive)",
  "optional_field": "string (optional)"
}
```

**Success Response (200):**
```json
{
  "data": { ... },
  "pagination": {
    "page": 1,
    "limit": 25,
    "total": 142,
    "totalPages": 6
  }
}
```

**Error Responses:**

| Status | Code | When |
|---|---|---|
| 400 | `BAD_REQUEST` | Malformed request syntax |
| 401 | `UNAUTHORIZED` | Missing/invalid authentication |
| 403 | `FORBIDDEN` | Insufficient permissions |
| 404 | `NOT_FOUND` | Resource doesn't exist |
| 422 | `VALIDATION_ERROR` | Business rule violation |
| 429 | `RATE_LIMITED` | Too many requests |
| 500 | `INTERNAL_ERROR` | Unexpected server error |

**Error Response Shape:**
```json
{
  "status": 422,
  "code": "VALIDATION_ERROR",
  "message": "Human-readable description",
  "details": [
    { "field": "acreage", "message": "Must be positive", "code": "POSITIVE_REQUIRED" }
  ]
}
```

---

[Repeat endpoint section for each endpoint]

## Rate Limits

| Tier | Limit | Window |
|---|---|---|
| Standard | [N] requests | per minute |
| Batch | [N] requests | per hour |

## Data Models

### [Model Name]
| Field | Type | Required | Description |
|---|---|---|---|
| `id` | string (UUID) | Auto | Unique identifier |
| `field_name` | string | Yes | [Description] |
| `created_at` | datetime (ISO 8601) | Auto | Creation timestamp |

## Versioning Strategy

[How will breaking changes be handled? URL versioning (/v1/, /v2/) or header-based?]

## Open Questions

- [ ] [Unanswered design question]
