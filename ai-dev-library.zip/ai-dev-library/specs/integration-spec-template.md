# Integration Spec: [Integration Name]

**Status:** Draft | In Review | Approved | In Progress | Complete
**Author:** [Name]
**Date:** [YYYY-MM-DD]

---

## Overview

[What systems are being integrated? What data or functionality flows between them?]

## Systems

| System | Role | Owner | Technology |
|---|---|---|---|
| [System A] | Source / Producer | [Team] | [Tech stack] |
| [System B] | Target / Consumer | [Team] | [Tech stack] |

## Data Flow

```
[System A] ──→ [Transform/Validate] ──→ [System B]
         trigger: [schedule/event/manual]
         format: [JSON/XML/CSV/direct DB]
         frequency: [real-time/hourly/daily/on-demand]
```

### Data Contract

| Field | Source | Target | Transform | Validation |
|---|---|---|---|---|
| [field] | [A.field] | [B.field] | [rule] | [constraint] |

## Integration Pattern

**Pattern:** [API Call / File Drop / Database Link / Message Queue / ETL Pipeline]

[Justify the chosen pattern. What are the alternatives and why were they rejected?]

## Error Handling

| Failure Scenario | Detection | Response | Recovery |
|---|---|---|---|
| Source unavailable | [How detected] | [What happens] | [How to recover] |
| Invalid data received | [Validation check] | [Reject/skip/queue] | [Manual review process] |
| Target unavailable | [Timeout/error code] | [Retry with backoff] | [Dead letter queue] |
| Partial failure | [Count mismatch] | [Log and continue] | [Reconciliation job] |

## Security

- **Authentication:** [How systems authenticate to each other]
- **Authorization:** [What permissions are granted]
- **Data in transit:** [Encryption: TLS, VPN, etc.]
- **Credential management:** [Where secrets are stored]

## Monitoring

| Metric | Alert Threshold | Notification |
|---|---|---|
| Records processed | 0 for > [N] hours | [Email/Slack/page] |
| Error rate | > [N]% | [Email/Slack/page] |
| Latency | > [N] seconds | [Log warning] |

## Testing Strategy

| Phase | Approach | Environment |
|---|---|---|
| Unit | Mock external system responses | Local |
| Integration | Connect to staging instances | Staging |
| Load | Simulate production volume | Staging |
| Acceptance | End-to-end with real data subset | Pre-production |

## Rollback Plan

[How to disconnect the integration without data loss or corruption]

## Open Questions

- [ ] [Unanswered question about the integration]
