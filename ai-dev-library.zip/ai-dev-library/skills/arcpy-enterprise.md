# Skill: ArcPy Enterprise Automation

> Enterprise GIS automation patterns using ArcPy for geodatabase management,
> spatial analysis, and environmental regulatory workflows.
> Customize [PLACEHOLDERS] with your project's specific values.

## Environment

- **Python:** 3.9+ (ArcGIS Pro 3.x bundled environment)
- **ArcGIS Pro:** 3.x with appropriate license level
- **Enterprise GDB:** Oracle or SQL Server via SDE connection files
- **Target OS:** Windows (Pro desktop environment)

## Standard Script Template

```python
"""
[Script Name] — [One-line description]

Purpose:
    [What this script does and why]

Author: [Author]
Created: [YYYY-MM-DD]
Modified: [YYYY-MM-DD]

Usage:
    python [script_name].py [--arg1 value1]

Dependencies:
    - arcpy (ArcGIS Pro 3.x)
    - [other packages]
"""

import arcpy
import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# ─── CONFIGURATION ──────────────────────────────────────────────
# Replace these with project-specific values or load from config.py

SDE_CONNECTION = r"[PATH_TO_SDE_CONNECTION_FILE]"
WORKSPACE = r"[PATH_TO_DEFAULT_WORKSPACE]"
LOG_DIR = Path(r"[PATH_TO_LOG_DIRECTORY]")
SPATIAL_REFERENCE = arcpy.SpatialReference([WKID])  # e.g., 2246 for KY StatePlane


def setup_logging(script_name: str) -> None:
    """Configure dual file/console logging with timestamp rotation."""
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = LOG_DIR / f"{script_name}_{timestamp}.log"

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler(sys.stdout),
        ],
    )


def main() -> None:
    """Entry point."""
    script_name = Path(__file__).stem
    setup_logging(script_name)

    logger.info("=" * 60)
    logger.info(f"Starting {script_name}")
    logger.info(f"ArcGIS Pro version: {arcpy.GetInstallInfo()['Version']}")
    logger.info(f"Workspace: {WORKSPACE}")
    logger.info("=" * 60)

    try:
        arcpy.env.workspace = WORKSPACE
        arcpy.env.overwriteOutput = True
        arcpy.env.outputCoordinateSystem = SPATIAL_REFERENCE

        # ── Business logic here ──
        pass

    except arcpy.ExecuteError:
        logger.error(f"Geoprocessing error:\n{arcpy.GetMessages(2)}")
        raise
    except Exception:
        logger.exception("Fatal error in main execution")
        raise
    finally:
        logger.info(f"Finished {script_name}")
        logger.info("=" * 60)


if __name__ == "__main__":
    main()
```

## Common Patterns

### Feature Class Iteration with Progress
```python
def process_features(
    fc_path: str,
    fields: list[str],
    where_clause: Optional[str] = None,
) -> int:
    """Iterate features with logging and progress tracking."""
    total = int(arcpy.management.GetCount(fc_path)[0])
    logger.info(f"Processing {total} features from {os.path.basename(fc_path)}")

    processed = 0
    errors = 0

    with arcpy.da.SearchCursor(fc_path, fields, where_clause) as cursor:
        for row in cursor:
            try:
                # Process individual feature
                processed += 1

                if processed % 1000 == 0:
                    logger.info(f"  Progress: {processed}/{total}")

            except Exception:
                errors += 1
                logger.exception(f"  Error on OID {row[fields.index('OID@')]}")

    logger.info(f"Complete: {processed} processed, {errors} errors out of {total}")
    return processed
```

### Versioned Editing on Enterprise SDE
```python
def edit_sde_features(
    sde_connection: str,
    fc_name: str,
    updates: list[dict],
) -> int:
    """Apply updates to a versioned feature class using an edit session."""
    fc_path = os.path.join(sde_connection, fc_name)

    if not arcpy.Exists(fc_path):
        raise ValueError(f"Feature class not found: {fc_path}")

    updated = 0

    with arcpy.da.Editor(sde_connection) as editor:
        editor.startEditing(with_undo=False, multiuser_mode=True)
        editor.startOperation()

        try:
            for update in updates:
                where = f"OBJECTID = {update['oid']}"
                fields = list(update['values'].keys())
                values = list(update['values'].values())

                with arcpy.da.UpdateCursor(fc_path, fields, where) as cursor:
                    for row in cursor:
                        cursor.updateRow(values)
                        updated += 1

            editor.stopOperation()
            editor.stopEditing(save_changes=True)
            logger.info(f"Successfully updated {updated} features")

        except Exception:
            editor.stopOperation()
            editor.stopEditing(save_changes=False)
            logger.exception("Edit operation failed — changes discarded")
            raise

    return updated
```

### Geodatabase Inventory
```python
def inventory_geodatabase(workspace: str) -> dict:
    """Produce a complete inventory of geodatabase contents."""
    arcpy.env.workspace = workspace
    inventory = {
        "feature_datasets": [],
        "feature_classes": [],
        "tables": [],
        "relationship_classes": [],
    }

    # Standalone feature classes
    for fc in arcpy.ListFeatureClasses() or []:
        desc = arcpy.Describe(fc)
        inventory["feature_classes"].append({
            "name": fc,
            "type": desc.shapeType,
            "spatial_reference": desc.spatialReference.name,
            "count": int(arcpy.management.GetCount(fc)[0]),
        })

    # Feature datasets and their contents
    for fds in arcpy.ListDatasets(feature_type="Feature") or []:
        ds_info = {"name": fds, "feature_classes": []}
        arcpy.env.workspace = os.path.join(workspace, fds)

        for fc in arcpy.ListFeatureClasses() or []:
            desc = arcpy.Describe(fc)
            ds_info["feature_classes"].append({
                "name": fc,
                "type": desc.shapeType,
                "count": int(arcpy.management.GetCount(fc)[0]),
            })

        inventory["feature_datasets"].append(ds_info)
        arcpy.env.workspace = workspace

    # Tables
    for table in arcpy.ListTables() or []:
        inventory["tables"].append({
            "name": table,
            "count": int(arcpy.management.GetCount(table)[0]),
        })

    return inventory
```

## Anti-Patterns

```python
# ❌ Hardcoded SDE connection with embedded password
conn = r"C:\Users\chris\AppData\Roaming\ESRI\...\myserver.sde"

# ✅ Config-driven, password-free connection reference
from config import SDE_CONNECTIONS
conn = SDE_CONNECTIONS["production"]


# ❌ No existence check before processing
arcpy.analysis.Buffer(fc, output, "100 Feet")  # Crashes if fc doesn't exist

# ✅ Always verify
if not arcpy.Exists(fc):
    raise ValueError(f"Feature class not found: {fc}")
arcpy.analysis.Buffer(fc, output, "100 Feet")


# ❌ Ignoring geoprocessing messages
arcpy.management.Dissolve(input_fc, output_fc, "COUNTY")

# ✅ Check for warnings even on "success"
arcpy.management.Dissolve(input_fc, output_fc, "COUNTY")
warnings = arcpy.GetMessages(1)  # Warning messages
if warnings:
    logger.warning(f"Dissolve warnings: {warnings}")
```
