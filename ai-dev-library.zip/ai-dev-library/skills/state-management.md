# Skill: State Management Patterns

> State management patterns for React apps, ECS game architectures, and session management.
> Apply when building interactive UIs, games, or stateful systems.

## React State Management

### Decision Tree

```
Do I need this state?
├── Is it derivable from other state? → Don't store it, compute it
├── Is it only used in one component? → useState
├── Is it shared between siblings? → Lift to nearest common parent
├── Is it used across many unrelated components? → Context + useReducer
├── Is it server data that needs caching? → React Query / SWR
└── Is it complex with many transitions? → useReducer with typed actions
```

### useReducer for Complex State
```typescript
// Define state shape
interface EditorState {
  features: Feature[];
  selectedId: string | null;
  mode: 'view' | 'edit' | 'create';
  isDirty: boolean;
  error: string | null;
}

// Discriminated union for type-safe actions
type EditorAction =
  | { type: 'SELECT_FEATURE'; id: string }
  | { type: 'DESELECT' }
  | { type: 'SET_MODE'; mode: EditorState['mode'] }
  | { type: 'UPDATE_FEATURE'; id: string; changes: Partial<Feature> }
  | { type: 'ADD_FEATURE'; feature: Feature }
  | { type: 'DELETE_FEATURE'; id: string }
  | { type: 'SET_ERROR'; error: string }
  | { type: 'CLEAR_ERROR' }
  | { type: 'MARK_CLEAN' };

function editorReducer(state: EditorState, action: EditorAction): EditorState {
  switch (action.type) {
    case 'SELECT_FEATURE':
      return { ...state, selectedId: action.id, error: null };

    case 'UPDATE_FEATURE':
      return {
        ...state,
        isDirty: true,
        features: state.features.map((f) =>
          f.id === action.id ? { ...f, ...action.changes } : f
        ),
      };

    case 'DELETE_FEATURE':
      return {
        ...state,
        isDirty: true,
        features: state.features.filter((f) => f.id !== action.id),
        selectedId: state.selectedId === action.id ? null : state.selectedId,
      };

    // ... other cases
    default:
      return state;
  }
}
```

### Context Pattern for Shared State
```typescript
interface AppContextValue {
  state: EditorState;
  dispatch: React.Dispatch<EditorAction>;
}

const AppContext = createContext<AppContextValue | null>(null);

function useAppContext(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useAppContext must be used within AppProvider');
  return ctx;
}

function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(editorReducer, initialState);

  const value = useMemo(() => ({ state, dispatch }), [state]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
```

## ECS (Entity Component System) State — Game Architecture

### Core Pattern
```typescript
// Components are pure data
interface Position { x: number; y: number; z: number }
interface Velocity { dx: number; dy: number; dz: number }
interface Health { current: number; max: number }
interface Renderable { meshId: string; visible: boolean }

// Entity is just an ID with associated components
type EntityId = string;

interface World {
  entities: Map<EntityId, Set<string>>;         // entity → component names
  positions: Map<EntityId, Position>;
  velocities: Map<EntityId, Velocity>;
  health: Map<EntityId, Health>;
  renderables: Map<EntityId, Renderable>;
}

// Systems operate on entities with specific component combinations
function movementSystem(world: World, dt: number): void {
  for (const [entityId, velocity] of world.velocities) {
    const position = world.positions.get(entityId);
    if (!position) continue;

    position.x += velocity.dx * dt;
    position.y += velocity.dy * dt;
    position.z += velocity.dz * dt;
  }
}

function healthSystem(world: World): void {
  for (const [entityId, health] of world.health) {
    if (health.current <= 0) {
      destroyEntity(world, entityId);
    }
  }
}
```

### ECS Anti-Patterns
```
❌ Components with logic (methods that modify state)
✅ Components are pure data; systems contain all logic

❌ Systems that depend on other systems' execution order implicitly
✅ Explicit system execution order defined in game loop

❌ Entity references between components (tight coupling)
✅ Reference by EntityId, resolve at query time
```

## Session / Application State

### Finite State Machine Pattern
```typescript
type AppState =
  | { status: 'initializing' }
  | { status: 'authenticating' }
  | { status: 'authenticated'; user: User }
  | { status: 'error'; error: string; retryable: boolean };

// Valid transitions (enforced by logic, documented here)
// initializing → authenticating
// authenticating → authenticated | error
// error (retryable) → authenticating
// authenticated → initializing (logout)

function transition(current: AppState, event: AppEvent): AppState {
  switch (current.status) {
    case 'initializing':
      if (event.type === 'START_AUTH') return { status: 'authenticating' };
      return current;

    case 'authenticating':
      if (event.type === 'AUTH_SUCCESS') return { status: 'authenticated', user: event.user };
      if (event.type === 'AUTH_FAILURE') return { status: 'error', error: event.message, retryable: true };
      return current;

    // ... other transitions
  }
}
```

## General Rules

1. **Single source of truth** — Each piece of state lives in exactly one place
2. **Derive don't store** — If you can compute it from existing state, don't store it separately
3. **Immutable updates** — Always create new state objects, never mutate in place
4. **Type your state** — Discriminated unions prevent impossible states
5. **State transitions are explicit** — Use reducers or state machines, not scattered setState calls
