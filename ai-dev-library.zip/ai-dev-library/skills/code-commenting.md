# Skill: Code Commenting Standards

> Documentation standards for all code generation across Python, C#, TypeScript, and SQL.
> Apply this skill to ALL code output.

## Universal Rules

1. **Comments explain WHY, not WHAT** — The code shows what; comments explain the reasoning
2. **Every function gets a docstring** — Purpose, parameters, returns, exceptions
3. **File headers on every file** — What the file does, who owns it, when it was created
4. **Inline comments for non-obvious logic** — If you'd have to think about it, comment it
5. **No commented-out code** — Version control remembers. Delete it.
6. **Keep comments current** — Stale comments are worse than no comments

## Python

### File Header
```python
"""
[Module Name] — [One-line description]

Purpose:
    [2-3 sentences about what this module does and why it exists]

Author: [Name]
Created: [YYYY-MM-DD]
Modified: [YYYY-MM-DD]

Dependencies:
    - [package]: [what it's used for]

Notes:
    - [Any important context, known limitations, or gotchas]
"""
```

### Function Docstring (Google Style)
```python
def calculate_buffer_distance(
    permit_type: str,
    acreage: float,
    has_water_feature: bool = False,
) -> float:
    """Calculate the regulatory buffer distance for a mining permit.

    Uses Kentucky DMRE regulations to determine the minimum buffer
    distance based on permit type, disturbed acreage, and proximity
    to water features. Water features trigger a 100-foot minimum
    regardless of permit type.

    Args:
        permit_type: Permit classification code (e.g., "SURFACE", "UNDERGROUND").
        acreage: Total disturbed acreage of the permit area.
        has_water_feature: Whether the buffer area intersects a water feature.

    Returns:
        Buffer distance in feet.

    Raises:
        ValueError: If permit_type is not a recognized classification.
        ValueError: If acreage is negative.

    Example:
        >>> calculate_buffer_distance("SURFACE", 50.0, has_water_feature=True)
        200.0
    """
```

### Inline Comments
```python
# Good: explains WHY
# Buffer must be at least 100ft per KRS 350.060 when within
# 300ft of a perennial stream
if has_water_feature:
    min_buffer = max(min_buffer, 100.0)

# Bad: restates the code
# Set min_buffer to 100 if has_water_feature is True
if has_water_feature:
    min_buffer = max(min_buffer, 100.0)
```

## C#

### XML Documentation
```csharp
/// <summary>
/// Validates permit boundary geometry against regulatory topology rules.
/// </summary>
/// <remarks>
/// Checks for self-intersections, minimum area requirements, and
/// overlap with restricted zones. Must be called inside QueuedTask.Run().
/// </remarks>
/// <param name="geometry">The permit boundary polygon to validate.</param>
/// <param name="permitType">Permit classification for rule selection.</param>
/// <returns>
/// A <see cref="ValidationResult"/> containing pass/fail status
/// and any violation descriptions.
/// </returns>
/// <exception cref="ArgumentNullException">
/// Thrown when <paramref name="geometry"/> is null.
/// </exception>
/// <exception cref="GeodatabaseException">
/// Thrown when spatial query against restricted zones fails.
/// </exception>
public ValidationResult ValidateBoundary(Geometry geometry, string permitType)
```

## TypeScript

### JSDoc on Components and Functions
```typescript
/**
 * Displays a terrain mesh generated from DEM elevation data.
 *
 * Manages its own Three.js scene lifecycle including geometry disposal.
 * Supports dynamic resolution adjustment based on camera distance.
 *
 * @param elevationData - 2D array of elevation values in meters
 * @param resolution - Grid resolution in meters per cell (default: 30)
 * @param colorRamp - Color scheme for elevation visualization
 * @returns void - renders to the provided canvas ref
 *
 * @example
 * ```tsx
 * <TerrainMesh
 *   elevationData={demGrid}
 *   resolution={10}
 *   colorRamp="terrain"
 * />
 * ```
 */
```

## SQL

### Query Headers
```sql
-- =============================================================================
-- Query: [Name]
-- Purpose: [What this query does and when it's used]
-- Author: [Name]
-- Date: [YYYY-MM-DD]
-- Parameters:
--   :permit_id  — The target permit identifier
--   :start_date — Beginning of the reporting period
-- Notes:
--   - Uses CTE for readability; tested against [N] records in [X]ms
--   - Index on permits(status, county_code) required for performance
-- =============================================================================
```

## What NOT to Comment

```python
# ❌ Obvious from the code
i += 1  # Increment i

# ❌ Commented-out code (delete it)
# old_value = calculate_old_way(data)
# if old_value > threshold:
#     process_old(old_value)

# ❌ Redundant with type hints
def get_name(user_id: int) -> str:
    """Get the name."""  # This docstring adds nothing

# ❌ TODO without context
# TODO: fix this  # Fix WHAT? WHY? WHEN?

# ✅ Useful TODO
# TODO(chris, 2026-04): Migrate to new API endpoint after v3 launch.
#   See DL-007-api-migration.md for migration plan.
```
