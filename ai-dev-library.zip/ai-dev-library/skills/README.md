# Skills — Domain Knowledge & Pattern Libraries

> Reusable skill files that encode domain expertise, code patterns, and conventions.
> Fork into your project's `ai-dev/skills/` and customize with project-specific values.

## Inventory

| Skill | File | Applies To |
|---|---|---|
| ArcPy Enterprise Automation | `arcpy-enterprise.md` | Python GIS automation, geodatabase management |
| ArcGIS Pro SDK Add-ins | `arcgis-pro-sdk.md` | C# add-in development for ArcGIS Pro |
| TypeScript Web Applications | `typescript-webapp.md` | React, Next.js, Three.js, Vite projects |
| Enterprise Geodatabase | `enterprise-gdb.md` | Oracle/SQL Server SDE, versioning, replication |
| Error Handling Patterns | `error-handling.md` | Cross-language error handling, logging, recovery |
| Code Commenting Standards | `code-commenting.md` | Documentation standards across all languages |
| API Design Patterns | `api-design.md` | REST endpoints, validation, versioning |
| State Management | `state-management.md` | React state, ECS patterns, session management |

## Usage

Reference from CLAUDE.md:
```
Read ai-dev/skills/arcpy-enterprise.md for ArcPy patterns.
```

In a Claude Code prompt:
```
Read ai-dev/skills/error-handling.md before writing any code.
```

## Customization

When forking a skill into a project:
1. Copy the generic skill file into `ai-dev/skills/`
2. Add project-specific connection names, feature class paths, field schemas
3. Add project-specific anti-patterns you've encountered
4. Update examples to use your project's actual data structures
