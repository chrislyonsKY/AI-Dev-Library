# Skill: TypeScript Web Application Patterns

> Conventions for React/Next.js, Three.js, and Vite-based TypeScript projects.
> Customize [PLACEHOLDERS] with project-specific values.

## Environment

- **Runtime:** Node.js 20+ / Bun
- **Language:** TypeScript 5.x with `strict: true`
- **Frameworks:** React 18+, Next.js 14+, Vite 5+
- **3D:** Three.js r160+ / Babylon.js 6+
- **Styling:** Tailwind CSS 3+ or CSS Modules

## tsconfig Baseline

```json
{
  "compilerOptions": {
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "forceConsistentCasingInFileNames": true,
    "esModuleInterop": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "paths": { "@/*": ["./src/*"] }
  }
}
```

## Project Structure (Vite + React)

```
src/
├── components/            # Reusable UI components
│   ├── ui/                # Primitives (Button, Input, Modal)
│   └── features/          # Feature-specific compound components
├── hooks/                 # Custom React hooks
├── lib/                   # Utility functions, API clients
├── types/                 # Shared TypeScript type definitions
├── stores/                # State management (context, reducers)
├── scenes/                # Three.js scene managers (if 3D)
├── assets/                # Static assets (images, fonts, models)
├── styles/                # Global styles, Tailwind config
└── App.tsx                # Root component
```

## Key Patterns

### Custom Hook with Error Handling
```typescript
function useFeatureData(featureId: string | null) {
  const [state, setState] = useState<AsyncState<Feature>>({ status: 'idle' });

  useEffect(() => {
    if (!featureId) {
      setState({ status: 'idle' });
      return;
    }

    const controller = new AbortController();
    setState({ status: 'loading' });

    fetchFeature(featureId, { signal: controller.signal })
      .then((data) => setState({ status: 'success', data }))
      .catch((err) => {
        if (err.name === 'AbortError') return;
        setState({ status: 'error', error: err.message });
      });

    return () => controller.abort();
  }, [featureId]);

  return state;
}
```

### Three.js Resource Cleanup
```typescript
// CRITICAL: Dispose all GPU resources on unmount
function useThreeScene(canvasRef: React.RefObject<HTMLCanvasElement>) {
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
    const scene = new THREE.Scene();
    let animId: number;

    const animate = () => {
      animId = requestAnimationFrame(animate);
      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(animId);
      scene.traverse((obj) => {
        if (obj instanceof THREE.Mesh) {
          obj.geometry.dispose();
          const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
          mats.forEach((m) => m.dispose());
        }
      });
      renderer.dispose();
    };
  }, []);
}
```

### Type-Safe API Client
```typescript
type ApiResult<T> =
  | { ok: true; data: T }
  | { ok: false; error: { code: string; message: string } };

async function api<T>(
  path: string,
  options?: RequestInit,
): Promise<ApiResult<T>> {
  try {
    const res = await fetch(`/api/v1${path}`, {
      headers: { 'Content-Type': 'application/json' },
      ...options,
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ message: res.statusText }));
      return { ok: false, error: { code: String(res.status), message: err.message } };
    }

    return { ok: true, data: await res.json() };
  } catch (err) {
    return {
      ok: false,
      error: { code: 'NETWORK', message: err instanceof Error ? err.message : 'Network error' },
    };
  }
}
```

## Anti-Patterns

```typescript
// ❌ `any` type
const process = (data: any) => { ... }
// ✅ Explicit types
const process = (data: FeatureCollection): ProcessResult => { ... }

// ❌ useEffect without cleanup
useEffect(() => { const ws = new WebSocket(url); }, []);
// ✅ Cleanup
useEffect(() => {
  const ws = new WebSocket(url);
  return () => ws.close();
}, []);

// ❌ Index access without check (noUncheckedIndexedAccess)
const first = items[0].name; // might be undefined!
// ✅ Guard
const first = items[0];
if (first) console.log(first.name);
```
