# Skill: ArcGIS Pro SDK Add-in Development

> Patterns and conventions for building ArcGIS Pro add-ins with the Pro SDK (C#/.NET).
> Customize [PLACEHOLDERS] with your project's specific values.

## Environment

- **ArcGIS Pro:** 3.x
- **SDK:** ArcGIS Pro SDK for .NET (matching Pro version)
- **Framework:** .NET 8 (or as specified by SDK version)
- **UI Pattern:** WPF with strict MVVM
- **IDE:** Visual Studio 2022+

## Threading Model (CRITICAL)

| Thread | Access Via | What Runs Here |
|---|---|---|
| **UI Thread** | Direct calls, DispatcherTimer | UI updates, ViewModel property changes |
| **CIM Thread** | `QueuedTask.Run()` | ALL map, layer, geometry, geodatabase, CIM operations |

**THE GOLDEN RULE:** Never access map, layer, feature, geometry, or CIM objects outside `QueuedTask.Run()`.

## Project Structure

```
[AddInName]/
├── Config.daml                          # Add-in registration
├── Module1.cs                           # Module entry point
├── ViewModels/
│   └── [Feature]ViewModel.cs            # MVVM ViewModels (all logic here)
├── Views/
│   └── [Feature]View.xaml               # XAML only — NO code-behind logic
├── Services/
│   └── [Domain]DataService.cs           # Geodatabase access layer
├── Models/
│   └── [Domain]Record.cs                # Data transfer objects
├── Helpers/
│   └── ProSdkHelpers.cs                 # Reusable utility methods
└── Images/                              # Icons (16x16, 32x32)
```

## Key Patterns

### ViewModel Base
```csharp
internal class FeatureDockPaneViewModel : DockPane
{
    private const string DockPaneId = "[AddInName]_DockPane";
    private string _statusMessage = "Ready";
    private bool _isProcessing;
    private RelayCommand? _executeCommand;

    public string StatusMessage
    {
        get => _statusMessage;
        set => SetProperty(ref _statusMessage, value);
    }

    public bool IsProcessing
    {
        get => _isProcessing;
        set
        {
            SetProperty(ref _isProcessing, value);
            ExecuteCommand.RaiseCanExecuteChanged();
        }
    }

    public RelayCommand ExecuteCommand =>
        _executeCommand ??= new RelayCommand(
            async () => await ExecuteAsync(),
            () => !IsProcessing);

    private async Task ExecuteAsync()
    {
        IsProcessing = true;
        StatusMessage = "Processing...";

        try
        {
            await QueuedTask.Run(() =>
            {
                // ALL map/CIM/geodatabase access here
            });
            StatusMessage = "Complete";
        }
        catch (Exception ex)
        {
            StatusMessage = $"Error: {ex.Message}";
        }
        finally
        {
            IsProcessing = false;
        }
    }
}
```

### Data Service Pattern
```csharp
/// <summary>
/// Encapsulates geodatabase access for [domain] data.
/// All public methods must be called inside QueuedTask.Run().
/// </summary>
internal class DomainDataService : IDisposable
{
    private Geodatabase? _geodatabase;
    private bool _disposed;

    public void Connect(string connectionPath)
    {
        _geodatabase = new Geodatabase(
            new DatabaseConnectionFile(new Uri(connectionPath)));
    }

    public IReadOnlyList<DomainRecord> Query(string? whereClause = null)
    {
        if (_geodatabase is null) throw new InvalidOperationException("Not connected");

        var results = new List<DomainRecord>();
        var filter = new QueryFilter { WhereClause = whereClause ?? "1=1" };

        using var table = _geodatabase.OpenDataset<Table>("[TABLE_NAME]");
        using var cursor = table.Search(filter);

        while (cursor.MoveNext())
        {
            using var row = cursor.Current;
            results.Add(MapToRecord(row));
        }

        return results;
    }

    public void Dispose()
    {
        if (!_disposed)
        {
            _geodatabase?.Dispose();
            _disposed = true;
        }
    }
}
```

### Anti-Patterns
```csharp
// ❌ Map access outside QueuedTask
var layers = MapView.Active.Map.GetLayersAsFlattenedList(); // CRASH

// ✅ Map access inside QueuedTask
var layers = await QueuedTask.Run(() =>
    MapView.Active?.Map?.GetLayersAsFlattenedList());


// ❌ Logic in code-behind
public partial class MyView : UserControl {
    private void Button_Click(object sender, RoutedEventArgs e) {
        var fc = OpenFeatureClass(); // WRONG — belongs in ViewModel
    }
}

// ✅ Command binding in XAML + logic in ViewModel
// <Button Command="{Binding ExecuteCommand}" Content="Run" />


// ❌ Not disposing cursors
var cursor = table.Search(filter);
while (cursor.MoveNext()) { /* ... */ }
// cursor leaked!

// ✅ Using statement
using var cursor = table.Search(filter);
```

## Review Checklist

- [ ] All map/CIM/geodatabase access inside `QueuedTask.Run()`
- [ ] All public members have XML doc comments
- [ ] No logic in code-behind (MVVM only)
- [ ] All IDisposable objects use `using`
- [ ] DAML IDs match class names
- [ ] Icons provided in both 16x16 and 32x32
