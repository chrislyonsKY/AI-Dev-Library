# Skill: Enterprise Geodatabase Patterns

> Architecture and operational patterns for Oracle/SQL Server enterprise geodatabases
> with SDE, versioned editing, and replication workflows.

## Enterprise GDB Architecture

### Connection Hierarchy
```
Database Server (Oracle / SQL Server)
└── Enterprise Geodatabase (SDE)
    ├── Connection Files (.sde)
    │   ├── PROD_READONLY.sde   — Read-only for reports/queries
    │   ├── PROD_EDITOR.sde     — Edit access for automation scripts
    │   └── DEV_ADMIN.sde       — Schema modification in development
    ├── Feature Datasets
    │   └── [DATASET] (spatial reference container)
    │       ├── Feature Classes
    │       └── Topology Rules
    ├── Standalone Feature Classes
    ├── Tables (non-spatial)
    ├── Relationship Classes
    ├── Domains (coded value / range)
    └── Versions
        ├── sde.DEFAULT (production baseline)
        ├── [DEPARTMENT].[VERSION] (working versions)
        └── Quality control via reconcile/post workflow
```

### Connection File Management
```python
# NEVER embed credentials in code. Use pre-configured .sde files.
# Store connection files in a secured, backed-up network location.

CONNECTION_PATHS = {
    "prod_read": r"\\gisserver\connections\PROD_READONLY.sde",
    "prod_edit": r"\\gisserver\connections\PROD_EDITOR.sde",
    "staging":   r"\\gisserver\connections\STG_EDITOR.sde",
    "dev":       r"\\gisserver\connections\DEV_ADMIN.sde",
}

# Principle of least privilege:
# - Reports/queries → read-only connection
# - Automation edits → editor connection
# - Schema changes → admin connection (dev only)
```

## Versioned Editing Workflow

```
1. Create named version from DEFAULT
   ├── arcpy.management.CreateVersion(sde, "sde.DEFAULT", "EDIT_2026Q1", "PROTECTED")
   
2. Connect to named version
   ├── arcpy.management.ChangeVersion(layer, "TRANSACTIONAL", "EDITOR.EDIT_2026Q1")
   
3. Edit within version (edit session)
   ├── with arcpy.da.Editor(workspace) as editor:
   │       editor.startEditing(with_undo=False, multiuser_mode=True)
   │       editor.startOperation()
   │       # ... make edits ...
   │       editor.stopOperation()
   │       editor.stopEditing(save_changes=True)
   
4. QA review of edits in version
   
5. Reconcile with DEFAULT
   ├── arcpy.management.ReconcileVersions(sde, "ALL_VERSIONS", "sde.DEFAULT",
   │       "EDITOR.EDIT_2026Q1", "LOCK_ACQUIRED", "NO_ABORT", "BY_OBJECT", "FAVOR_EDIT_VERSION")
   
6. Post to DEFAULT (if no conflicts)
   ├── arcpy.management.PostVersion(sde, "EDITOR.EDIT_2026Q1")
   
7. Delete working version
   └── arcpy.management.DeleteVersion(sde, "EDITOR.EDIT_2026Q1")
```

## Schema Design Rules

### Naming Conventions
```
Feature Datasets:   PascalCase          → PermitBoundaries, WaterResources
Feature Classes:    PascalCase          → ActivePermits, MonitoringWells
Tables:             PascalCase          → InspectionLog, OperatorRegistry
Fields:             UPPER_SNAKE_CASE    → PERMIT_ID, COUNTY_CODE, CREATED_DATE
Domains:            d_[Description]     → d_PermitStatus, d_CountyCode
Relationship Classes: rel_[Origin]_[Dest] → rel_Permits_Inspections
Indexes:            IDX_[Table]_[Field] → IDX_PERMITS_STATUS
```

### Required Fields (Every Table)
```
OBJECTID          — System-managed OID
SHAPE             — Geometry (feature classes only)
CREATED_DATE      — Timestamp of record creation
CREATED_BY        — Username who created the record
MODIFIED_DATE     — Timestamp of last modification
MODIFIED_BY       — Username who last modified
GLOBALID          — System-managed GUID (required for replication/offline)
```

## Performance Patterns

### Spatial Index Tuning
```python
# After bulk loading, rebuild spatial indexes
arcpy.management.RebuildIndexes(sde_connection, "NO_SYSTEM", "FeatureClassName")

# For Oracle: Analyze statistics after bulk operations
arcpy.management.AnalyzeDatasets(sde_connection, "NO_SYSTEM", "FeatureClassName", "ANALYZE_BASE")
```

### Query Optimization
```sql
-- Use spatial indexes: query by envelope first, then precise geometry
-- ❌ Slow: geometry operation on entire table
SELECT * FROM permits WHERE SDO_CONTAINS(shape, :point_geom) = 'TRUE'

-- ✅ Fast: filter by envelope first
SELECT * FROM permits
WHERE SDO_FILTER(shape, :search_envelope) = 'TRUE'
  AND SDO_CONTAINS(shape, :point_geom) = 'TRUE'
```

## Anti-Patterns

```
❌ Direct DEFAULT version editing in production
✅ Always edit in a named version, reconcile/post after QA

❌ Schema changes in production without testing in dev/staging
✅ Test all schema modifications in dev → staging → production

❌ Opening multiple edit sessions simultaneously
✅ One edit session per workspace per script execution

❌ Forgetting to rebuild indexes after bulk loads
✅ Always RebuildIndexes + AnalyzeDatasets after bulk operations

❌ Using direct SQL (INSERT/UPDATE) on SDE-managed tables
✅ Always use ArcPy cursors or geoprocessing tools for SDE data
```
