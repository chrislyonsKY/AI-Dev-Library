# Skill: API Design Patterns

> REST API design, validation, versioning, and error response patterns.
> Apply when building backend endpoints for web applications.

## Core Principles

1. **RESTful resource naming** — Nouns, not verbs. Plural. `/api/permits`, not `/api/getPermit`
2. **Consistent error responses** — Same error shape everywhere
3. **Validate at the boundary** — Never trust client input
4. **Version from day one** — `/api/v1/permits`
5. **Paginate collections** — Never return unbounded lists

## URL Design

```
GET    /api/v1/permits              — List permits (paginated)
GET    /api/v1/permits/:id          — Get single permit
POST   /api/v1/permits              — Create permit
PUT    /api/v1/permits/:id          — Full update
PATCH  /api/v1/permits/:id          — Partial update
DELETE /api/v1/permits/:id          — Delete permit

GET    /api/v1/permits/:id/inspections  — Nested resource

Query parameters for filtering and pagination:
GET    /api/v1/permits?status=active&county=PIKE&page=1&limit=25&sort=-created_date
```

## Standard Error Response

```typescript
interface ApiError {
  status: number;         // HTTP status code
  code: string;           // Machine-readable error code
  message: string;        // Human-readable message
  details?: ErrorDetail[];// Field-level errors for validation
  requestId?: string;     // For support/debugging
}

interface ErrorDetail {
  field: string;
  message: string;
  code: string;
}

// Example: 422 Validation Error
{
  "status": 422,
  "code": "VALIDATION_ERROR",
  "message": "Request validation failed",
  "details": [
    { "field": "acreage", "message": "Must be a positive number", "code": "POSITIVE_REQUIRED" },
    { "field": "county_code", "message": "Must be exactly 3 characters", "code": "INVALID_LENGTH" }
  ],
  "requestId": "req_abc123"
}
```

## Standard HTTP Status Codes

| Code | Meaning | When to Use |
|---|---|---|
| 200 | OK | Successful GET, PUT, PATCH |
| 201 | Created | Successful POST that creates a resource |
| 204 | No Content | Successful DELETE |
| 400 | Bad Request | Malformed request syntax |
| 401 | Unauthorized | Missing or invalid authentication |
| 403 | Forbidden | Valid auth but insufficient permissions |
| 404 | Not Found | Resource doesn't exist |
| 409 | Conflict | Duplicate creation, optimistic lock failure |
| 422 | Unprocessable Entity | Valid syntax but failed business rules |
| 429 | Too Many Requests | Rate limit exceeded |
| 500 | Internal Server Error | Unexpected server failure |

## Pagination Pattern

```typescript
interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
    hasNext: boolean;
    hasPrev: boolean;
  };
}

// Response example
{
  "data": [...],
  "pagination": {
    "page": 2,
    "limit": 25,
    "total": 142,
    "totalPages": 6,
    "hasNext": true,
    "hasPrev": true
  }
}
```

## Input Validation Pattern (TypeScript / Zod)

```typescript
import { z } from 'zod';

const CreatePermitSchema = z.object({
  operator_name: z.string().min(1).max(200),
  county_code: z.string().length(3),
  permit_type: z.enum(['SURFACE', 'UNDERGROUND', 'COAL_REFUSE']),
  acreage: z.number().positive(),
  application_date: z.string().datetime(),
});

type CreatePermitInput = z.infer<typeof CreatePermitSchema>;

// In route handler
const parsed = CreatePermitSchema.safeParse(req.body);
if (!parsed.success) {
  return res.status(422).json({
    status: 422,
    code: 'VALIDATION_ERROR',
    message: 'Request validation failed',
    details: parsed.error.issues.map(issue => ({
      field: issue.path.join('.'),
      message: issue.message,
      code: issue.code,
    })),
  });
}
```

## Anti-Patterns

```
❌ Verbs in URLs: /api/getPermit, /api/deleteUser
✅ Nouns: GET /api/permits/:id, DELETE /api/users/:id

❌ Inconsistent error shapes (sometimes string, sometimes object)
✅ Same ApiError structure for every error response

❌ Returning all records: GET /api/permits → 50,000 records
✅ Paginated: GET /api/permits?page=1&limit=25

❌ Trusting client input: const sql = `SELECT * FROM ${req.params.table}`
✅ Validate and whitelist: const table = ALLOWED_TABLES[req.params.table]
```
