# Skill: Error Handling Patterns

> Cross-language error handling, logging, and recovery patterns.
> Apply this skill to ALL code generation regardless of language.

## Universal Principles

1. **Fail loudly, recover gracefully** — Log the full error, show the user a helpful message
2. **Specific exceptions only** — Never catch `Exception` or `except:` without re-raising
3. **Context in every error** — Include what was being done, what input caused it, what to try next
4. **Structured logging** — Use the logging framework, not print/Console.Write
5. **Clean up on failure** — Resources (files, connections, cursors) must be released in finally/using

## Python Patterns

### Standard Error Handling
```python
import logging

logger = logging.getLogger(__name__)

def process_record(record_id: str, data: dict) -> ProcessResult:
    """Process a single record with comprehensive error handling."""
    logger.info(f"Processing record {record_id}")

    try:
        validated = validate_input(data)
        result = transform(validated)
        save(result)
        logger.info(f"Successfully processed record {record_id}")
        return ProcessResult(success=True, record_id=record_id)

    except ValidationError as e:
        # Expected error — log as warning, return failure result
        logger.warning(f"Validation failed for {record_id}: {e}")
        return ProcessResult(success=False, record_id=record_id, error=str(e))

    except ConnectionError as e:
        # Infrastructure error — log as error, may want to retry
        logger.error(f"Connection failed processing {record_id}: {e}")
        raise  # Let caller decide retry strategy

    except Exception:
        # Unexpected error — log full traceback
        logger.exception(f"Unexpected error processing {record_id}")
        raise
```

### Batch Processing with Partial Failure
```python
def process_batch(records: list[dict]) -> BatchResult:
    """Process records individually so one failure doesn't stop the batch."""
    result = BatchResult()

    for record in records:
        try:
            process_record(record["id"], record)
            result.succeeded += 1
        except Exception:
            logger.exception(f"Failed to process record {record.get('id', 'UNKNOWN')}")
            result.failed += 1
            result.failures.append(record.get("id", "UNKNOWN"))

    logger.info(f"Batch complete: {result.succeeded} succeeded, {result.failed} failed")

    if result.failed > 0:
        logger.warning(f"Failed records: {result.failures}")

    return result
```

### ArcPy-Specific Error Handling
```python
import arcpy

try:
    arcpy.analysis.Buffer(input_fc, output_fc, "100 Feet")
except arcpy.ExecuteError:
    logger.error(f"Geoprocessing failed:\n{arcpy.GetMessages(2)}")
    raise
except Exception:
    logger.exception("Non-geoprocessing error in buffer operation")
    raise
```

## C# Patterns

### Standard Try-Catch
```csharp
public async Task<ProcessResult> ProcessFeatureAsync(string featureId)
{
    Logger.Info($"Processing feature {featureId}");

    try
    {
        var result = await QueuedTask.Run(() =>
        {
            // Map/CIM operations here
            return DoProcessing(featureId);
        });

        Logger.Info($"Successfully processed feature {featureId}");
        return result;
    }
    catch (GeodatabaseException ex)
    {
        Logger.Error(ex, $"Geodatabase error processing {featureId}");
        throw; // Rethrow — let caller handle
    }
    catch (OperationCanceledException)
    {
        Logger.Warn($"Processing cancelled for {featureId}");
        return ProcessResult.Cancelled;
    }
    catch (Exception ex)
    {
        Logger.Error(ex, $"Unexpected error processing {featureId}");
        throw;
    }
}
```

## TypeScript Patterns

### Async Error Handling
```typescript
async function fetchFeatureData(id: string): Promise<Result<FeatureData, AppError>> {
  try {
    const response = await fetch(`/api/features/${id}`);

    if (!response.ok) {
      return {
        ok: false,
        error: {
          type: 'http',
          status: response.status,
          message: `Failed to fetch feature ${id}: ${response.statusText}`,
        },
      };
    }

    const data = await response.json();
    return { ok: true, value: data };

  } catch (err) {
    return {
      ok: false,
      error: {
        type: 'network',
        message: err instanceof Error ? err.message : 'Network error',
      },
    };
  }
}
```

## Anti-Patterns (All Languages)

```
❌ Swallowing exceptions silently
   try { ... } catch { }  // Error vanishes into the void

❌ Catching too broadly
   except Exception as e:
       return None  // Hides bugs

❌ Logging without context
   logger.error("An error occurred")  // WHAT error? WHERE? Processing WHAT?

❌ Using error codes instead of exceptions
   return -1  // Caller forgets to check, chaos ensues

❌ Retry without backoff or limit
   while True:
       try: do_thing()
       except: continue  // Infinite loop on persistent failure
```

## Logging Level Guide

| Level | When to Use | Example |
|---|---|---|
| `DEBUG` | Detailed diagnostic info for developers | `"Query returned 47 rows for permit_id=123"` |
| `INFO` | Normal operation milestones | `"Starting daily permit sync"` |
| `WARNING` | Unexpected but recoverable | `"Validation failed for 3 records, continuing"` |
| `ERROR` | Operation failed, needs attention | `"Database connection timeout after 3 retries"` |
| `CRITICAL` | System-level failure | `"Cannot start — config file missing"` |
