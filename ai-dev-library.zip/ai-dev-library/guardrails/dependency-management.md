# Dependency Management Guardrails

> Package policies, version pinning, and audit requirements.

## Version Pinning

- **Python:** Pin exact versions in `requirements.txt` (`pandas==2.1.4`, not `pandas>=2.0`)
- **Node.js:** Use exact versions or lock files (`package-lock.json` / `bun.lockb`)
- **C#/.NET:** Pin versions in `.csproj` (`<PackageReference Include="X" Version="1.2.3" />`)
- **Never use `latest` or `*` in production dependencies**

## Allowed Sources

| Language | Approved Registry | Notes |
|---|---|---|
| Python | PyPI (pypi.org) | ArcPy comes bundled with Pro |
| Node.js | npm (npmjs.com) | Prefer packages with >1M weekly downloads |
| C# | NuGet (nuget.org) | Esri Pro SDK packages from Esri feed |

## Pre-Approval Required — [CUSTOMIZE]

The following categories require explicit approval before adding:
- Packages with network access capabilities (HTTP clients, socket libraries)
- Packages that process credentials or authentication
- Packages with native/binary extensions
- Packages with fewer than 100 GitHub stars or no recent maintenance (12+ months)
- Any package not on the approved registry list

## Audit Requirements

- Run `pip audit` or `npm audit` before every release
- Known vulnerabilities with severity High or Critical block deployment
- Document accepted risk for Medium vulnerabilities in `ai-dev/decisions/`
- Review dependency licenses for compatibility (avoid GPL in proprietary projects)

## Update Policy

- Security patches: Apply within 1 week of disclosure
- Minor versions: Evaluate monthly, apply if tests pass
- Major versions: Evaluate quarterly, test thoroughly before adopting
- Pin and document the reason when intentionally staying on an older version

## Anti-Patterns

```
❌ requirements.txt with unpinned versions
pandas
numpy
requests

✅ Pinned versions
pandas==2.1.4
numpy==1.26.2
requests==2.31.0


❌ Installing random packages to solve one problem
pip install some-obscure-package-with-3-downloads

✅ Evaluate first: maintenance status, download count, license, alternatives
```
