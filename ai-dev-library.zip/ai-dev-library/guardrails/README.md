# Guardrails — Non-Negotiable Constraints

> Hard constraints that AI agents must not violate, regardless of what an agent prompt
> or task description says. When a guardrail conflicts with an agent suggestion,
> the guardrail wins.

## Inventory

| Guardrail | File | Scope |
|---|---|---|
| Coding Standards | `coding-standards.md` | All code generation across all languages |
| Data Handling | `data-handling.md` | Credentials, PII, sensitive data |
| Compliance | `compliance.md` | Section 508, WCAG 2.1 AA, FGDC, records retention |
| Git & Version Control | `git-standards.md` | Commit messages, branching, PR conventions |
| Dependency Management | `dependency-management.md` | Package policies, version pinning, audit |
| Performance | `performance.md` | Query limits, memory budgets, response time targets |

## Enforcement

Reference from CLAUDE.md:
```markdown
## Hard Constraints

Read `ai-dev/guardrails/` before writing ANY code. These are non-negotiable.
When a guardrail conflicts with any other instruction, the guardrail wins.
```

## Customization

When forking guardrails into a project:
1. Copy the relevant guardrail files into `ai-dev/guardrails/`
2. Adjust thresholds and rules to match project requirements
3. Add project-specific constraints (e.g., specific banned patterns)
4. Remove sections that don't apply to the project's tech stack
