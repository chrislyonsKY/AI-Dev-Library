# Coding Standards Guardrails

> These rules apply to ALL code generated for this project, regardless of which agent
> is active. Violations are treated as Critical findings in code review.

## Python

- All scripts must include logging configuration (no bare `print()` for operational output)
- All database queries must use parameterized binds (no string concatenation — EVER)
- All file paths must use `os.path.join()` or `pathlib.Path` (no hardcoded separators)
- All cursors, connections, and file handles must use `with` statements (no manual open/close)
- All functions must have type hints on parameters and return values
- All functions must have docstrings (Google style: Args, Returns, Raises)
- All exception handling must be specific (no bare `except:` or `except Exception:` without re-raise)
- Target: Python 3.9+ (ArcGIS Pro 3.x bundled environment)
- Line length: 100 characters max
- Import order: stdlib → third-party → local (separated by blank lines)

## C#

- All CIM/map/geodatabase access MUST be inside `QueuedTask.Run()`
- All public members must have `///` XML documentation comments
- No code-behind logic in XAML views (MVVM pattern only)
- All `IDisposable` objects must use `using` statements
- Nullable reference types enabled (`<Nullable>enable</Nullable>`)
- All public method parameters must have null checks (guard clauses)
- Async methods must follow Pro SDK threading model

## TypeScript

- `strict: true` in tsconfig — no exceptions
- No `any` type — use `unknown` and narrow, or define proper types
- No `as` type casts except at validated API boundaries
- All `useEffect` hooks that create resources must return cleanup functions
- All component props must have TypeScript interfaces with JSDoc comments
- All interactive elements must be keyboard-accessible
- All Three.js resources (geometry, material, texture) must be disposed on unmount

## SQL

- All queries must use bind parameters (NEVER interpolate user input)
- Uppercase keywords, lowercase identifiers: `SELECT permit_id FROM permits WHERE status = :status`
- Explicit column lists required (no `SELECT *` in production code)
- All DDL must include `COMMENT ON` for tables and columns
- All tables must include audit columns (CREATED_DATE, CREATED_BY, MODIFIED_DATE, MODIFIED_BY)

## All Languages

- No hardcoded credentials, API keys, or connection strings in source code
- No hardcoded file paths — use configuration or environment variables
- No magic numbers or strings — extract to named constants
- Error messages must include context (what was being done, what input caused the failure)
- All code must be formatted consistently (use project formatter config)
