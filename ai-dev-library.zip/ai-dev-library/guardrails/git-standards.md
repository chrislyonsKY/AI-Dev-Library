# Git & Version Control Guardrails

> Commit message conventions, branching strategy, and PR standards.

## Commit Message Format

```
<type>(<scope>): <description>

[optional body]

[optional footer]
```

### Types

| Type | When to Use |
|---|---|
| `feat` | New feature or capability |
| `fix` | Bug fix |
| `refactor` | Code restructuring (no behavior change) |
| `docs` | Documentation only |
| `style` | Formatting, whitespace (no logic change) |
| `test` | Adding or updating tests |
| `chore` | Build, config, dependency updates |
| `perf` | Performance improvement |

### Examples
```
feat(permits): add batch export to Excel
fix(sync): handle null county_code in permit records
refactor(data-service): extract validation into separate module
docs(readme): add deployment instructions for staging
chore(deps): update arcpy-stubs to 3.2.1
```

### Rules
- Subject line: 72 characters max, imperative mood ("add" not "added" or "adds")
- Body: Wrap at 72 characters, explain WHAT and WHY (not HOW)
- Reference issue/ticket numbers in footer: `Closes #42` or `Ref: JIRA-123`
- One logical change per commit (don't bundle unrelated changes)

## Branching Strategy

```
main (or master)
├── develop                    ← Integration branch
│   ├── feature/permit-export  ← New features
│   ├── feature/map-tool-v2
│   ├── fix/null-county-crash  ← Bug fixes
│   └── refactor/data-layer    ← Refactoring
├── release/v2.1.0             ← Release preparation
└── hotfix/critical-sync-fix   ← Emergency production fixes
```

### Branch Naming
```
feature/[short-description]    — New feature work
fix/[short-description]        — Bug fixes
refactor/[short-description]   — Code restructuring
docs/[short-description]       — Documentation updates
chore/[short-description]      — Maintenance, deps, config
```

## .gitignore Requirements

Every project MUST ignore:
```gitignore
# Credentials and secrets
config.py
*.sde
.env
.env.*
*.key
*.pem
secrets/

# IDE
.vs/
.vscode/
*.suo
*.user
__pycache__/
*.pyc

# Build artifacts
bin/
obj/
dist/
build/
node_modules/

# OS files
.DS_Store
Thumbs.db

# Logs (retained separately per records policy)
logs/
*.log
```

## Pre-Commit Checklist

Before every commit:
- [ ] No credentials, API keys, or connection strings in the diff
- [ ] No PII or sensitive data in the diff
- [ ] Commit message follows the type(scope): description format
- [ ] One logical change per commit
- [ ] All tests pass (if applicable)
