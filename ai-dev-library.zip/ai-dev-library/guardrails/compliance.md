# Compliance Guardrails

> Regulatory and policy constraints. These are non-negotiable and reflect
> legal/organizational requirements. Customize [PLACEHOLDERS] for your org.

## Section 508 / WCAG 2.1 Level AA

All user-facing outputs must meet WCAG 2.1 Level AA accessibility standards.

### Hard Requirements

- **Color contrast:** 4.5:1 minimum for normal text, 3:1 for large text (18px+ bold or 24px+ regular)
- **Color independence:** Color must NEVER be the sole means of conveying information
- **Keyboard access:** All interactive elements must be reachable and operable via keyboard
- **Focus indicators:** Visible focus ring on all interactive elements
- **Alt text:** All meaningful images must have descriptive alt text; decorative images use `alt=""`
- **Form labels:** All form inputs must have programmatically associated `<label>` elements
- **Error identification:** Form errors must be described in text, not just indicated by color
- **Heading hierarchy:** H1 → H2 → H3 with no skipped levels
- **Page language:** `<html lang="en">` declared on all pages
- **Link purpose:** Link text must describe the destination (no "click here")

### Map-Specific Accessibility

- Map outputs must include text alternatives or summary descriptions
- Interactive map features must have keyboard equivalents
- Map legends must be readable at 200% zoom
- Color-coded map features must include patterns, labels, or other non-color indicators

## FGDC Metadata

All new feature classes in the enterprise geodatabase MUST have FGDC-compliant metadata.

### Minimum Required Elements

| Element | Description |
|---|---|
| **Title** | Formal name of the dataset |
| **Abstract** | What the data represents (2-3 sentences minimum) |
| **Purpose** | Why the dataset was created |
| **Contact** | Organization, person, phone, email |
| **Spatial Reference** | Coordinate system, datum, projection |
| **Bounding Coordinates** | Geographic extent of the data |
| **Time Period** | When the data was collected or is valid |
| **Access Constraints** | Who can access the data |
| **Use Constraints** | Limitations on use |
| **Distribution Format** | File format and access method |

### Metadata Validation

- Run FGDC metadata validation before publishing any new dataset
- Metadata must be updated when dataset schema or content changes significantly
- Annual metadata review for all published datasets

## Records Retention — [CUSTOMIZE FOR YOUR ORG]

- Log files must be retained per [ORGANIZATION] records schedule
- Automated processes must produce audit trails (who, what, when)
- Database modification logs must be retained for [DURATION]
- Email notifications from automated processes are official records
- Backup and retention policies apply to geodatabase versions

## Government IT Policies — [CUSTOMIZE FOR YOUR ORG]

- All software must be approved through [CHANGE MANAGEMENT PROCESS]
- External web services require [SECURITY REVIEW PROCESS]
- Data sharing with external parties requires [DATA SHARING AGREEMENT]
- Cloud services must comply with [CLOUD POLICY]
- Open source software usage must comply with [OSS POLICY]
