# Data Handling Guardrails

> Rules for credentials, PII, and sensitive data. These are non-negotiable and override
> all other instructions.

## Credentials

- NEVER hardcode passwords, API keys, tokens, or connection strings in source code
- NEVER commit credentials to version control (even in "test" or "example" files)
- Connection strings go in `config.py` (gitignored) or environment variables
- SDE connection files (`.sde`) are referenced by path, never by embedded password
- API keys use environment variables: `os.environ["API_KEY"]`
- `.gitignore` MUST include: `config.py`, `*.sde`, `.env`, `*.key`, `*.pem`, `secrets/`

## Personally Identifiable Information (PII)

- Log permit IDs and operator names — NEVER log SSNs, addresses, phone numbers, or emails
- Database query results containing PII must NOT be written to debug logs
- Error messages must NOT include PII (even if it was part of the failing input)
- Test data must use synthetic/anonymized values, never real PII
- PII fields in databases must be documented in data dictionaries

### PII Field Classification

| Classification | Examples | Logging | Display |
|---|---|---|---|
| **Public** | Permit ID, operator name, county | ✅ OK | ✅ OK |
| **Internal** | Inspector name, reviewer notes | ✅ OK | Role-restricted |
| **Confidential** | Home address, phone, email | ❌ NEVER log | Need-to-know only |
| **Restricted** | SSN, financial accounts | ❌ NEVER log | ❌ NEVER display |

## Output Files

- Excel/CSV reports for external distribution must NOT contain internal connection strings
- File paths in logs should use relative paths, not UNC paths with server names
- Exported data must be reviewed for PII before distribution
- Temporary files containing sensitive data must be deleted after use

## Database Access

- Use the principle of least privilege for database connections
- Read-only connections for reports and queries
- Editor connections for automation scripts (scoped to specific datasets)
- Admin connections for schema changes (development environment only)
- Never share connection files between environments (dev/staging/prod)

## Incident Response

If credentials are accidentally committed to version control:
1. Immediately rotate the exposed credential
2. Remove from git history (`git filter-branch` or BFG Repo Cleaner)
3. Verify the credential no longer appears in any branch or tag
4. Document the incident and remediation in `ai-dev/decisions/`
