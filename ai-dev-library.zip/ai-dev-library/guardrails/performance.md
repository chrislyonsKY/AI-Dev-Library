# Performance Guardrails

> Query limits, memory budgets, and response time targets.
> Customize thresholds for your project's specific requirements.

## Database Query Rules

- **Row limits:** All user-facing queries must have a `LIMIT` / `FETCH FIRST` clause or pagination
- **Max result set:** Never return more than [10,000] rows in a single query without pagination
- **Query timeout:** Set statement timeout to [30] seconds for interactive queries
- **Index requirement:** Every `WHERE` clause column used in production queries must have an index
- **No `SELECT *`:** Explicit column lists only — reduces I/O and prevents schema-change surprises
- **Batch operations:** Bulk inserts/updates must be batched ([1,000] rows per batch)

## Memory Budgets

| Context | Budget | Action if Exceeded |
|---|---|---|
| Python script (ArcPy) | 4 GB | Use cursors instead of loading all to memory |
| ArcGIS Pro add-in | 500 MB | Stream results, dispose objects immediately |
| Web API response | 10 MB | Paginate, compress, or use streaming |
| Browser client (React) | 200 MB | Virtualize long lists, lazy-load data |
| Three.js scene | 512 MB GPU | LOD, instancing, dispose unused resources |

## Response Time Targets

| Operation | Target | Maximum |
|---|---|---|
| UI interaction (button click) | < 100ms | 200ms |
| Simple database query | < 500ms | 2s |
| Complex spatial analysis | < 5s | 30s |
| Report generation | < 10s | 60s |
| Batch processing per record | < 100ms/record | 500ms/record |
| Web page load (initial) | < 2s | 5s |
| API endpoint response | < 500ms | 3s |

## Spatial Data Performance

- **Feature class size threshold:** Feature classes > 100K features should have spatial indexes tuned
- **Geometry simplification:** Use appropriate tolerance for display vs. analysis
- **Tile caching:** Map services with > 10 concurrent users should use tile caching
- **Spatial queries:** Always use spatial index-aware query patterns (filter by envelope first)

## Monitoring Requirements

- All production scripts must log execution time for major operations
- Database queries taking > [5s] must trigger a warning log entry
- Batch operations must log progress every [1,000] records
- Memory-intensive operations should log peak memory usage

## Anti-Patterns

```
❌ Loading entire table into memory
all_records = [row for row in cursor]  # 500K rows into a list

✅ Stream processing with cursors
with arcpy.da.SearchCursor(fc, fields) as cursor:
    for row in cursor:  # One row at a time
        process(row)


❌ N+1 query pattern
for permit in permits:
    inspections = query_inspections(permit.id)  # 1 query per permit!

✅ Batch query
permit_ids = [p.id for p in permits]
all_inspections = query_inspections_batch(permit_ids)  # 1 query total


❌ No timeout on external calls
response = requests.get(url)  # Hangs forever if server is down

✅ Timeout configured
response = requests.get(url, timeout=30)
```
